require IEx # Para utilizar IEx.pry

defmodule ServidorGV do
    @moduledoc """
        modulo del servicio de vistas
    """
   # Constantes
    @latidos_fallidos 4

    @intervalo_latidos 50

    # Tipo estructura de datos que guarda el estado del servidor de vistas
    # COMPLETAR  con lo campos necesarios para gestionar
    # el estado del gestor de vistas
    defstruct   vista_valida: %{num_vista: 0, primario: :undefined, copia: :undefined}, 
                vista_tentativa: %{num_vista: 0, primario: :undefined, copia: :undefined},
                lista_espera: [],
                lista_latidos: [],
                timeouts_primario: @latidos_fallidos + 1,
                timeouts_copia: @latidos_fallidos + 1,
                debug_vistas_generadas: []

    @doc """
        Acceso externo para constante de latidos fallios
    """
    def latidos_fallidos() do
        @latidos_fallidos
    end

    @doc """
        acceso externo para constante intervalo latido
    """
   def intervalo_latidos() do
       @intervalo_latidos
   end

   @doc """
        Generar un estructura de datos vista inicial
    """
    def vista_inicial() do
        %{num_vista: 0, primario: :undefined, copia: :undefined}
    end

    @doc """
        Poner en marcha el servidor para gestión de vistas
        Devolver atomo que referencia al nuevo nodo Elixir
    """
    @spec startNodo(String.t, String.t) :: node
    def startNodo(nombre, maquina) do
                                         # fichero en curso
        NodoRemoto.start(nombre, maquina, __ENV__.file)
    end

    @doc """
        Poner en marcha servicio trás esperar al pleno funcionamiento del nodo
    """
    @spec startService(node) :: boolean
    def startService(nodoElixir) do
        NodoRemoto.esperaNodoOperativo(nodoElixir, __MODULE__)
        
        # Poner en marcha el código del gestor de vistas
        Node.spawn(nodoElixir, __MODULE__, :init_sv, [])
   end

    #------------------- FUNCIONES PRIVADAS ----------------------------------

    # Estas 2 primeras deben ser defs para llamadas tipo (MODULE, funcion,[])
    def init_sv() do
        Process.register(self(), :servidor_gv)

        spawn(__MODULE__, :init_monitor, [self()]) # otro proceso concurrente

        #### VUESTRO CODIGO DE INICIALIZACION
       # #IO.inspect(%ServidorGV{}, label: "Estado inicial")
        bucle_recepcion(%ServidorGV{})
    end

    def init_monitor(pid_principal) do
        send(pid_principal, :procesa_situacion_servidores)
        Process.sleep(@intervalo_latidos)
        init_monitor(pid_principal)
    end


    defp bucle_recepcion(estado) do
        estado = receive do
                    {:latido, n_vista_latido, nodo_emisor} ->
                      #  #IO.inspect(estado, label: "Estado actual")
                        case estado.vista_tentativa.num_vista do
                        #No existe primario ni copia
                            0 -> #IO.puts "Primer primario"
                                estadoNuevo = %{estado | vista_tentativa: %{estado.vista_tentativa 
                                        | num_vista: (estado.vista_tentativa.num_vista + 1), primario: nodo_emisor},
                                         timeouts_primario: @latidos_fallidos + 1}
                           #     #IO.inspect(estadoNuevo.vista_tentativa, label: "estado a enviar")
                                send({:cliente_gv, nodo_emisor}, {:vista_tentativa , estadoNuevo.vista_tentativa, false})
                                estadoNuevo
                        #Existe primario pero no copia
                            1 -> cond do
                                    #Latido primario
                                    nodo_emisor == estado.vista_tentativa.primario ->  #IO.puts "Es primario"
                                                send({:cliente_gv, nodo_emisor}, {:vista_tentativa , estado.vista_tentativa, false})
                                                %{estado | timeouts_primario: @latidos_fallidos + 1 }
                                    #latido nueva copia
                                    n_vista_latido == 0 -> IO.puts "se generara una nueva copia"
                                                estadoNuevo = %{estado | vista_tentativa: %{estado.vista_tentativa 
                                                                                | num_vista: (estado.vista_tentativa.num_vista + 1), 
                                                                                        copia: nodo_emisor},
                                                                    timeouts_copia: @latidos_fallidos + 1}
                                                send({:cliente_gv, nodo_emisor}, {:vista_tentativa , estadoNuevo.vista_tentativa, 
                                                        true})
                                                #IO.inspect(estadoNuevo.vista_tentativa, label: "estado Nuevo\n")
                                                %{estadoNuevo | vista_valida: estadoNuevo.vista_tentativa}
                                    true -> IO.puts "Estado vista 1, Error al recibir numero vista"
                                            estado
                                end
                            _-> cond do
                                    nodo_emisor == estado.vista_tentativa.primario ->
                                        nEstado = cond do
                                            n_vista_latido == 0 -> IO.puts "**********>\npromocionando nuevo primario, primario caido\n<**********"
                                                            nuevoEstado = %{estado | lista_espera: estado.lista_espera ++ [nodo_emisor], 
                                                                                    lista_latidos: estado.lista_latidos ++ [nodo_emisor]}
                                                            promocionarPrimario(nuevoEstado)
                                                                    
                                                                   
                                            n_vista_latido == estado.vista_tentativa.num_vista 
                                                and estado.vista_tentativa != estado.vista_valida ->
                                                    IO.puts "Vista Validada"
                                                    %{estado | vista_valida: estado.vista_tentativa, timeouts_primario: @latidos_fallidos + 1}

                                            true -> IO.puts "Primario: n_vista = " <> to_string(n_vista_latido) <> "\n"
                                                    ##IO.inspect(estado.vista_valida, label: "Vista Valida")
                                                    #IO.inspect(estado.vista_tentativa, label: "Vista Tentativa")
                                                %{estado | timeouts_primario: @latidos_fallidos + 1}                    
                                        end
                                        send({:cliente_gv, nodo_emisor}, {:vista_tentativa , nEstado.vista_tentativa, 
                                                                nEstado.vista_tentativa==nEstado.vista_valida})
                                        nEstado

                                    nodo_emisor == estado.vista_tentativa.copia ->
                                       if n_vista_latido == 0 do
                                            IO.puts "-------\nPromocionando nueva copia, copia caida\n-----"
                                            nuevoEstado = %{estado| lista_espera: estado.lista_espera ++ [nodo_emisor], 
                                                            lista_latidos: estado.lista_latidos ++ [nodo_emisor]}
                                            nuevoEstado = promocionarNuevaCopia(nuevoEstado)
                                            send({:cliente_gv, nodo_emisor}, {:vista_tentativa , nuevoEstado.vista_tentativa, 
                                                            nuevoEstado.vista_tentativa==nuevoEstado.vista_valida})
                                            nuevoEstado
                                        else
                                            send({:cliente_gv, nodo_emisor}, {:vista_tentativa , estado.vista_tentativa, 
                                                            estado.vista_tentativa==estado.vista_valida})
                                            %{estado | timeouts_copia: @latidos_fallidos + 1}
                                        end
                                    true -> IO.puts "Latido recibido de " <> to_string(nodo_emisor) <> " vista " <> to_string(n_vista_latido)
                                       nuevoEstado = if n_vista_latido == 0 do
                                                if Enum.member?(estado.lista_espera, nodo_emisor) do
                                                    %{estado | lista_latidos: [nodo_emisor] ++ estado.lista_latidos}  
                                                else
                                                    if estado.vista_tentativa.primario != :undefined 
                                                            and estado.vista_tentativa.copia == :undefined do
                                                        #si no hay copia definida
                                                        %{estado | vista_tentativa: %{estado.vista_tentativa | copia: nodo_emisor, 
                                                                                            num_vista: estado.vista_tentativa.num_vista + 1},
                                                                    timeouts_copia: @latidos_fallidos + 1}
                                                    else
                                                        %{estado |  lista_espera: [nodo_emisor] ++ estado.lista_espera,
                                                            lista_latidos: [nodo_emisor] ++ estado.lista_latidos}
                                                    end
                                                end
                                        else
                                            %{estado | lista_latidos: [nodo_emisor] ++ estado.lista_latidos}
                                        end
                                        send({:cliente_gv, nodo_emisor}, {:vista_tentativa , nuevoEstado.vista_tentativa, 
                                                            nuevoEstado.vista_tentativa==nuevoEstado.vista_valida})
                                        nuevoEstado
                                end
                        end
                        
                
                    {:obten_vista, pid} -> #IO.inspect(estado, label: "Obtener vista\n")
                                    send(pid, {:vista_valida, estado.vista_valida, estado.vista_tentativa == estado.vista_valida})
                                            estado              

                    {:obten_lista_espera, pid} -> send(pid, {:lista_espera, estado.lista_espera})
                                                    estado

                    :procesa_situacion_servidores ->
                        estadoRestado = %{estado | timeouts_primario: estado.timeouts_primario-1,
                                   timeouts_copia: estado.timeouts_copia-1}
                        nuevoEstado = case estadoRestado.vista_tentativa.num_vista do
                            0-> estadoRestado
                            1-> IO.puts "fallos superados en primario en vista 1"
                                    if(estadoRestado.timeouts_primario== 0)do 
                                        %{estadoRestado |  debug_vistas_generadas: estadoRestado.debug_vistas_generadas ++ [estadoRestado.vista_tentativa],
                                                            vista_tentativa: vista_inicial()}
                                    else
                                        estadoRestado
                                    end
                            _ -> cond do
                                    estadoRestado.timeouts_primario == 0 and estadoRestado.timeouts_copia == 0 -> #IO.inspect(estado.debug_vistas_generadas, label: "CRASHHH!!!!(Primario y copia Caidos)\n")
                                                                 esr = %{estadoRestado | vista_tentativa: %{estadoRestado.vista_tentativa | primario: :undefined, copia: :undefined}}
                                                                #IO.inspect(esr, label: "ambos caidos, nuevo estado\n")
                                                                esr
                                    estadoRestado.timeouts_primario == 0 -> "\n*/*/*/*/*/*/*/*/\n TIMEOUT primario FAIL\n\n"
                                                                            promocionarPrimario(estadoRestado)
                                    estadoRestado.timeouts_copia == 0 ->  IO.puts "\n*/*/*/*/*/*/*/*/\n TIMEOUT copia FAIL\n\n"
                                                                            esta = promocionarNuevaCopia(estadoRestado)
                                                                            #IO.inspect(esta.debug_vistas_generadas, label: "vistas generadas\n")
                                                                            #IO.inspect(esta.vista_tentativa, label: "Nueva vista tentativa")
                                                                            esta
                                    true -> estadoRestado
                                end
                        end
                        #IO.inspect(nuevoEstado, label: "Procesar situacion servidores nuevo")
                        %{nuevoEstado | lista_latidos: []}
        end

        bucle_recepcion(estado)
    end
    
    #
    def promocionarPrimario(estado) do
        IO.puts "generando nuevo primario"
            #primaryOld = estado.vista_actual.primario
        if estado.vista_tentativa == estado.vista_valida do
            nuevoEstado = %{estado | vista_tentativa: %{estado.vista_tentativa 
                                        | primario: estado.vista_valida.copia, copia: :undefined}, timeouts_primario: estado.timeouts_copia}
            promocionarNuevaCopia(nuevoEstado)
        else
            #CRASH
            #IO.inspect(estado, label: "Ultimo estado\n")
            %{estado | vista_tentativa: %{estado.vista_tentativa | primario: :undefined}}
        end
    end


    def promocionarNuevaCopia(estado) do
        IO.puts "generando nueva copia"
        if estado.vista_tentativa.primario == :undefined do
            %{estado | vista_tentativa: %{estado.vista_tentativa | copia: :undefined}}
        else
            estadoNuevo = if estado.lista_espera == [] do 
                ##IO.inspect(estado.debug_vistas_generadas, label: "CRASHHH!!!!(sin lista_espera)\n")
                #%{estado | vista_tentativa: %{estado.vista_tentativa | primario: :undefined, copia: :undefined}}
                %{estado | vista_tentativa: %{estado.vista_tentativa | copia: :undefined, num_vista: (estado.vista_tentativa.num_vista + 1)}}
            else
                if estado.lista_latidos == [] do
                    nuevaCopia = hd(estado.lista_espera)
                    %{estado | vista_tentativa: %{estado.vista_tentativa 
                                                | num_vista: (estado.vista_tentativa.num_vista + 1), copia: nuevaCopia},
                                                lista_espera: tl(estado.lista_espera)}
                else 
                    nuevaCopia = hd(estado.lista_latidos)
                    %{estado | vista_tentativa: %{estado.vista_tentativa 
                                                | num_vista: (estado.vista_tentativa.num_vista + 1), copia: nuevaCopia},
                                                timeouts_copia: @latidos_fallidos + 1, lista_latidos: tl(estado.lista_latidos),
                                                lista_espera: List.delete(estado.lista_espera, nuevaCopia)}
                end
            end
            %{ estadoNuevo | debug_vistas_generadas: estadoNuevo.debug_vistas_generadas ++ [{estadoNuevo.vista_valida, estadoNuevo.vista_tentativa}]}
        end
    end
end
