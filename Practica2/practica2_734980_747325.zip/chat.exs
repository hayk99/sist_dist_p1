defmodule Chat do

	def sharedDB(variables) do

		receive do
									
					#Acceso a CS = true, actualizar numero secuencia, reiniciar replys
			{:waitInitME, pidT} ->  #IO.puts "WaitInitME recibido, se procede a modificar"
									Map.update!(variables, :Requesting_Critical_Section, &(&1 = true))
									Map.update!(variables, :Our_Sequence_Number, &(&1 = variables[:Highest_Sequence_Number] + 1))
									#IO.puts "send ACK WIME"
									send(pidT, {:ack, variables[:Our_Sequence_Number]})
					
					#Marca que se ha salido de la seccion critica y envia la lista de nodos a contestar                           
			:SaliendoEM -> 	#IO.puts "Saliendo EM"
							Map.update!(variables, :Requesting_Critical_Section, &(&1 = false))
							send({:IME,Node.self()}, {:defer, variables[:Reply_Deferred_List]})

		  
			{:waitRquest, pidReq, numSeqReq, idReq} -> if variables[:Highest_Sequence_Number] < numSeqReq do
														Map.update!(variables, :Highest_Sequence_Number, &(&1 = numSeqReq))
													end
													if checkDeferIt(variables, numSeqReq, idReq) do
														Map.update!(variables, :Reply_Deferred_List, &(&1 = variables[:Reply_Deferred_List] ++ [pidReq]))
														send({:ReqProcess, Node.self()}, :ackTrue)
													else
														send({:ReqProcess, Node.self()}, :ackFalse)
													end
		end

		sharedDB(variables)
	end

	def invokeMutualExclusion(me,listNodos, msg) do
		#TODO: darle una pensada a esto
		#IO.puts "Invocando exclusion mutua"
		send({:sDB, Node.self()}, {:waitInitME, {:IME, Node.self()}})
		send({:pidReply, Node.self()}, :resetNumNodos)
		receive do
			{:ack, seqNum} -> Enum.each(listNodos, 
										fn x ->  if x != Node.self() do
											send({:ReqProcess, x}, 
												{:request,me, Node.self(),seqNum})
											end end)
		#                       IO.puts "ack recibido"
		end
		
		#Waitfor 
		receive do                      
			:Continue -> Enum.each(listNodos, fn x ->if x != Node.self() do
														 	send({:showMSG, x}, {:msg, msg})
														 end end)
			#IO.puts "continue recibido"
		end
		#mostramos en pantalla
		#send({:showMSG, Node.self()}, {:msg, msg})
		send({:sDB, Node.self()}, :SaliendoEM)

		receive do
			{:defer, deferred_List} -> Enum.each(deferred_List, fn x -> send({:pidReply, x}, :reply) end)
		end
	end


	def chatInput(me, listNodos) do
		invokeMutualExclusion(me, listNodos, IO.gets "/>")
		chatInput(me, listNodos)
	end

	def checkDeferIt(variables, numSeqReq, idReq) do
		(variables[:Requesting_Critical_Section] and 
			((numSeqReq > variables[:Our_Sequence_Number]) or 
				((numSeqReq == variables[:Our_Sequence_Number]) 
					and idReq > variables[:me])))
	end

	#Funcion que recibe las peticiones de otros clientes para entrar en la seccion critica
	#y que se encarga de responder a esas peticiones segun la especificacion del algoritmo
	#de Ricart-Agrawala
	def requestReceiver() do
		receive do
			{:request, idReq, pidReq, numSeqReq} ->  #IO.puts "Rquest cecibido"
													send({:sDB, Node.self()}, {:waitRquest, pidReq, numSeqReq, idReq})                    
													receive do 
															 :ackFalse -> #IO.puts "ackFalse recibido"
															 		send({:pidReply, pidReq}, :reply)

															 :ackTrue #-> #IO.puets "ackTrue recibido"
													 end  
		end
		requestReceiver()
	end

	#Funcion que recibe las respuestas y decrementa 
	#Outstanding_Reply_Count en 1 por cada respuesta
	#recibida. Es parte de la implementacion del algoritmo
	#de Ricart-Agrawala
	def replyReceiver(outstanding_Reply_Count, numNodos) do
		receive do
			:resetNumNodos -> # IO.puts "Reset reply recibido"
								replyReceiver(numNodos-1, numNodos)
			:reply ->   #IO.inspect(outstanding_Reply_Count, label: "Reply recibido, puedo continuar ")
						if outstanding_Reply_Count == 1 do
							send({:IME, Node.self()}, :Continue)
							#IO.puts "Continuo sended"	
						end
						replyReceiver(outstanding_Reply_Count-1, numNodos)
		end
	end

	def chatMostrar() do
		receive do
			{:msg, mensaje} -> IO.puts(mensaje)
								chatMostrar()
			#_ -> IO.puts "Error en mensaje"
		end
	end

	def spawnear(modulo, funcion, parametros, nombre) do
		Process.register(self(), nombre)
		apply(modulo, funcion, parametros)
	end

	def conectarNodo(node) do
		Node.connect node
	end

	#Funcion que inicializa el cliente del chat
	def comenzarChat(numNodos, me) do
		nodeList = [:"1@127.0.0.1", :"2@127.0.0.1"]
		Enum.each(nodeList, fn x -> conectarNodo(x) end)
		variables = %{:me => me, :NumNodos => numNodos, 
					:Our_Sequence_Number => 1, :Highest_Sequence_Number => 0, 
					:Outstanding_Reply_Count => 0, :Requesting_Critical_Section => false,
					:Reply_Deferred_List => []}
		#:sDB
		spawn(Chat, :spawnear, [Chat, :sharedDB, [variables], :sDB])
		#:showMSG
		spawn(Chat, :spawnear, [Chat, :chatMostrar, [], :showMSG])
		#:ReqProcess
		spawn(Chat, :spawnear, [Chat, :requestReceiver, [], :ReqProcess])
		#:pidReply
		spawn(Chat, :spawnear, [Chat, :replyReceiver, [0,numNodos], :pidReply])
		#:IME    
		Process.register(self(), :IME)      
		chatInput(me, nodeList)
	end
end


